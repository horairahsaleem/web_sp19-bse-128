import "./sharecomponents.css";
import PermMediaIcon from "@mui/icons-material/PermMedia";
import LabelImportantIcon from "@mui/icons-material/LabelImportant";
import RoomIcon from "@mui/icons-material/Room";
import EmojiEmotionsIcon from "@mui/icons-material/EmojiEmotions";
import { useContext, useRef, useState } from "react";
import { AuthContext } from "../../context/AuthContext";
import { Box, Button, Modal, TextField } from "@mui/material";
import axios from "axios";
const style = {
  position: "absolute",
  top: "50%",
  left: "50%",
  width: '70%',
  height: 'auto',
  transform: "translate(-50%, -50%)",
  display: 'flex',
  flexDirection: 'column',
  bgcolor: "background.paper",

  boxShadow: 24,
  pt: 2,
  px: 4,
  pb: 3,
};

const ShareComponents = (props) => {
  const { user } = useContext(AuthContext);
  const desc = useRef();
  const [file, setFile] = useState(null);
  const [isopen, setIsOpen] = useState(false);
  const [textone, settextone] = useState("");
  const [imageFile, setimageFile] = useState();
  const [textthree, settextthree] = useState("");
  const [textfour, settextfour] = useState("");
  const [textfive, settextfive] = useState("");

  const handleOpen = () => {
    setIsOpen(true);
  };
  const handleClose = () => {
    setIsOpen(false);
  };
  const getFormData = () => {
    var form_data = new FormData();
    form_data.append('userId',"647f892d7206e063045bfadf")
    form_data.append("desc", textone);
    form_data.append("likes", []);
    form_data.append("img", imageFile);
    return form_data;
  };
  const addPosts = async () => {

    try {
      const response = await axios.post(`http://localhost:8800/api/posts`,getFormData(),
      {
        onUploadProgress: (ProgressEvent) => {
          let progress =
            Math.round(
              (ProgressEvent.loaded / ProgressEvent.total) * 100
            ) + "%";
          console.log(progress)
        }
      }
      );

    
      setIsOpen(false);
      props.fetchPosts()
      console.log(response.data);
    } catch (error) {
      
    }
  

   
  };
  const handelSave = () => {
    addPosts();
  };
  return (
    <div className="sharecomponents">
      {/* <Button >Open modal</Button> */}
      <Modal
        open={isopen}
        onClose={handleClose}
        aria-labelledby="parent-modal-title"
        aria-describedby="parent-modal-description"
      >
        <Box sx={{ ...style}}>
          <h2 id="parent-modal-title">Add post</h2>
          <TextField
            id="standard-multiline-static"
            multiline
            rows={4}
            size="medium"
            label="Poat Data"
            variant="standard"
            style={{margin: '5%'}}
            value={textone}
            onChange={(e) => {
              settextone(e.target.value);
            }}
          />
          <input
            id="upload"
            type="file"
            accept="image/*"
            style={{margin: '5%'}}
            onChange={(e) => {
              setimageFile(e.target.files[0])
            }}
            onClick={(e) => {
              e.target.value = null;
            }}
          />

          {/* <TextField id="standard-basic" label="Standard" variant="standard" value={textthree} onChange={(e) => { settextthree(e.target.value)}} />
          <TextField id="standard-basic" label="Standard" variant="standard" value={textfour} onChange={(e) => { settextfour(e.target.value)}} />
          <TextField id="standard-basic" label="Standard" variant="standard" value={textfive} onChange={(e) => { settextfive(e.target.value)}} /> */}

          <Button variant="contained" onClick={handelSave}>Add</Button>
        </Box>
      </Modal>

      <div className="sharecomponentswrapper">
        <div className="sharecomponenttop">
          <img className="sharecomponentsimg" src="/assets/hhh.jpeg" alt="" />
          <input
            className="sharecomponentsinput"
            ref={desc}
            placeholder={`${user.username} Whats in your mind`}
          />
        </div>
        <hr className="sharecomponentshr" />
        <div className="sharecomponentbottom">
          <div className="sharecomponentsoptions">
            <div className="sharecomponentsoption" onClick={handleOpen}>
              <PermMediaIcon
                htmlColor="tomato"
                className="sharecomponentsicon"
              />
              <span className="sharecomponentsoptiontext">Photo or Video</span>
            </div>
            <div className="sharecomponentsoption">
              <LabelImportantIcon
                htmlColor="blue"
                className="sharecomponentsicon"
              />
              <span className="sharecomponentsoptiontext">Tag</span>
            </div>
            <div className="sharecomponentsoption">
              <RoomIcon htmlColor="green" className="sharecomponentsicon" />
              <span className="sharecomponentsoptiontext">Location</span>
            </div>
            <div className="sharecomponentsoption">
              <EmojiEmotionsIcon
                htmlColor="goldenrod"
                className="sharecomponentsicon"
              />
              <span className="sharecomponentsoptiontext">Feelings</span>
            </div>
          </div>
          <button className="sharecomponentsbutton">Share</button>
        </div>
      </div>
    </div>
  );
};

export default ShareComponents;
