import Post from "../post/Post";
import ShareComponents from "../shareComponents/ShareComponents";
import "./feed.css";
import { useEffect, useState } from "react";
import axios from "axios";

const Feed = ({ username }) => {
  const [posts, setPosts] = useState([]);
  const fetchPosts = async () => {
    const response = username
      ? await axios.get(`http://localhost:8800/api/posts/profile/${username}`)
      : await axios.get(
          `http://localhost:8800/api/posts/timeline/647f892d7206e063045bfadf`
        );

    console.log(response.data);

    setPosts(response.data);
  };
  useEffect(() => {
    fetchPosts();
  }, [username]);

  return (
    <div className="feed">
      <div className="feedwrapper">
        <ShareComponents fetchPosts={fetchPosts}/>
        {posts.map((p) => (
          <Post key={p._id} postFeed={p} />
        ))}
      </div>
    </div>
  );
};

export default Feed;
