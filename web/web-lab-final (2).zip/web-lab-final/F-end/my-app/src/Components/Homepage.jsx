import React,{useState,useEffect} from 'react'
import  axios from 'axios'


function Homepage() {
    const [dishtype,setdishtype]=useState('')
    const [dishname,setdishname]=useState('')
    const [calories,setcalories]=useState('')
    const [post,setpost]=useState({})
    // const [error,seterror]=useState('')

    const handler= ()=>{
        axios.post('http://localhost:8800/api/posts/',{
            type: dishtype,
            name: dishname,
            calories:calories


        })
        .then((response)=>{
            console.log(response)
        })
        .catch((error)=>{
console.log(error)
        })
    }
const gethandler=()=>{
    axios.get('http://localhost:8800/api/posts/:id')
    .then((response)=>{
        console.log(response)
        setpost({
            post:response.data
        }
        
        )

    })
    console.log(post)
    // .catch((error)=>{
    //     console.log(error)
    //     seterror({
    //         error:'API is not called properly there is an error'
    //     })
    // })
}
useEffect(()=>{
    gethandler()
})
   
  
        
    
  return (
    <div>
          <div>
 Type of food
 <input type="text"  value={dishtype} onChange={(e)=> setdishtype(e.target.value)}/>

          </div>
          <div>
            Name of dish
            <input type="text"  value={dishname} onChange={(e)=> setdishname(e.target.value)}/>

          </div>
          <div>
            Enter the calories
            <input type="text"  value={calories} onChange={(e)=> setcalories(e.target.value)}/>

          </div>
          <div>
            <button onClick={handler}>ADD DATA</button>
          </div>


          
    List of item Get from the apis    

   { post.map((value, index)=>{  return(
<> 
<div>{value.type}</div>
<div>{value.name}</div>
<div>{value.calories}</div>
</>
)}) }  
 
        {/* {
            post.length ? 
            post.map((ab)=> <div> ({ab.type}) and ({ab.name}) and ({ab.calories})</div>) : error
        }  */}
      



      
    </div>
  )
}

export default Homepage
