const mongoose = require("mongoose");

const PostSchema = new mongoose.Schema(
  {
    type: {
      type: String,
      
    },
    name: {
      type: String,
      
    },
    calories: {
      type: String,
    }
  
  },
  { timestamps: true }
);

module.exports = mongoose.model("Post", PostSchema);
