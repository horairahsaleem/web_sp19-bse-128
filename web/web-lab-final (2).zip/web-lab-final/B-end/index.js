const express = require("express");
const app = express();
const mongoose = require("mongoose");
const dotenv = require("dotenv");
const helmet = require("helmet");
const morgan = require("morgan");
const postRoute = require("./routes/posts");
const router = express.Router();
const path = require("path");
const cors = require('cors');


dotenv.config();

mongoose.connect('mongodb://127.0.0.1:27017/test', {
  useNewUrlParser: true,
  useUnifiedTopology: true
}).then(() => {
  console.log('MongoDB connected');
}).catch((error) => {
  console.error('MongoDB connection failed:', error);
});
app.use("/images", express.static(path.join(__dirname, "public/images")));
app.use(cors());
//middleware
app.use(express.json());
app.use(helmet());
app.use(morgan("common"));

app.use("/api/posts", postRoute);

app.listen(8800, () => {
  console.log("Backend server is running!");
});
