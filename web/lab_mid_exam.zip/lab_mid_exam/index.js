let element = document.getElementById("btn")

element.addEventListener('click', function(e) {
    alert("Wel come to cheetah site")
  })


  let a = document.getElementById("logo")
  a.addEventListener('mouseover', function(e) {
    alert("MY ID is SP19 BSE 128")
  })