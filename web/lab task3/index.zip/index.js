const express = require('express');
const session = require('express-session');
const bcrypt = require('bcrypt');

const app = express();

// Middleware to parse request bodies
app.use(express.urlencoded({ extended: true }));

// Configure session middleware
app.use(
  session({
    secret: 'secret-key',
    resave: false,
    saveUninitialized: false,
  })
);

// Mock user data for testing
const users = [
  {
    id: 1,
    username: 'user1',
    password: '$2b$10$ahGnsC86V8i7fLZkYmVQLeUwfrg2sAPrNqrcqllEg6DURl5kiTzJu', // "password"
  },
  // Add more user objects here if needed
];

// Home route
app.get('/', (req, res) => {
  res.send('Welcome to the authentication example');
});

// Login route
app.get('/login', (req, res) => {
  res.send(`
    <h2>Login</h2>
    <form method="post" action="/login">
      <div>
        <label for="username">Username:</label>
        <input type="text" name="username" required>
      </div>
      <div>
        <label for="password">Password:</label>
        <input type="password" name="password" required>
      </div>
      <div>
        <input type="submit" value="Login">
      </div>
    </form>
  `);
});

app.post('/login', (req, res) => {
  const { username, password } = req.body;

  // Find the user with the matching username
  const user = users.find((user) => user.username === username);

  if (!user) {
    res.send('Invalid username or password');
    return;
  }

  // Compare the provided password with the stored hashed password
  bcrypt.compare(password, user.password, (err, result) => {
    if (err || !result) {
      res.send('Invalid username or password');
    } else {
      // Store the user ID in the session
      req.session.userId = user.id;
      res.redirect('/dashboard');
    }
  });
});

// Registration route
app.get('/register', (req, res) => {
  res.send(`
    <h2>Register</h2>
    <form method="post" action="/register">
      <div>
        <label for="username">Username:</label>
        <input type="text" name="username" required>
      </div>
      <div>
        <label for="password">Password:</label>
        <input type="password" name="password" required>
      </div>
      <div>
        <input type="submit" value="Register">
      </div>
    </form>
  `);
});

app.post('/register', (req, res) => {
  const { username, password } = req.body;

  // Generate a salt and hash the password
  bcrypt.hash(password, 10, (err, hashedPassword) => {
    if (err) {
      res.send('Error occurred during registration');
      return;
    }

    // Mock user creation
    const newUser = {
      id: users.length + 1,
      username,
      password: hashedPassword,
    };
    users.push(newUser);

    // Store the user ID in the session
    req.session.userId = newUser.id;

    res.redirect('/dashboard');
  });
});

// Dashboard route
app.get('/dashboard', (req, res) => {
  // Check if the user is authenticated (user ID is stored in the session)
  if (req.session.userId) {
    res.send(`Welcome to the dashboard, user ${req.session.userId}!`);
  } else {
    res.redirect('/login');
  }
});

// Logout route
app.get('/logout', (req, res) => {
  // Destroy the session
  req.session.destroy(() => {
    res.redirect('/');
  });
});

// Start the server
app.listen(3000, () => {
  console.log('Server started on http://localhost:3000');
});
